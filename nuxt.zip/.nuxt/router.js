import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _e03c126c = () => interopDefault(import('..\\pages\\about-us.vue' /* webpackChunkName: "pages/about-us" */))
const _52a819dc = () => interopDefault(import('..\\pages\\change-password.vue' /* webpackChunkName: "pages/change-password" */))
const _251ef110 = () => interopDefault(import('..\\pages\\countries.vue' /* webpackChunkName: "pages/countries" */))
const _4a9f0370 = () => interopDefault(import('..\\pages\\create-account.vue' /* webpackChunkName: "pages/create-account" */))
const _31c720a6 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _8e2e071c = () => interopDefault(import('..\\pages\\poll-history.vue' /* webpackChunkName: "pages/poll-history" */))
const _46125358 = () => interopDefault(import('..\\pages\\polls.vue' /* webpackChunkName: "pages/polls" */))
const _89a08cfa = () => interopDefault(import('..\\pages\\privacy-policy.vue' /* webpackChunkName: "pages/privacy-policy" */))
const _3b13641c = () => interopDefault(import('..\\pages\\report-problem.vue' /* webpackChunkName: "pages/report-problem" */))
const _57fcc260 = () => interopDefault(import('..\\pages\\terms-and-conditions.vue' /* webpackChunkName: "pages/terms-and-conditions" */))
const _8315513a = () => interopDefault(import('..\\pages\\industry\\_industry.vue' /* webpackChunkName: "pages/industry/_industry" */))
const _40fd2838 = () => interopDefault(import('..\\pages\\poll-winner\\_pollid.vue' /* webpackChunkName: "pages/poll-winner/_pollid" */))
const _9d5d54c4 = () => interopDefault(import('..\\pages\\poll\\_pollid.vue' /* webpackChunkName: "pages/poll/_pollid" */))
const _1d74cc96 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about-us",
    component: _e03c126c,
    name: "about-us"
  }, {
    path: "/change-password",
    component: _52a819dc,
    name: "change-password"
  }, {
    path: "/countries",
    component: _251ef110,
    name: "countries"
  }, {
    path: "/create-account",
    component: _4a9f0370,
    name: "create-account"
  }, {
    path: "/login",
    component: _31c720a6,
    name: "login"
  }, {
    path: "/poll-history",
    component: _8e2e071c,
    name: "poll-history"
  }, {
    path: "/polls",
    component: _46125358,
    name: "polls"
  }, {
    path: "/privacy-policy",
    component: _89a08cfa,
    name: "privacy-policy"
  }, {
    path: "/report-problem",
    component: _3b13641c,
    name: "report-problem"
  }, {
    path: "/terms-and-conditions",
    component: _57fcc260,
    name: "terms-and-conditions"
  }, {
    path: "/industry/:industry?",
    component: _8315513a,
    name: "industry-industry"
  }, {
    path: "/poll-winner/:pollid?",
    component: _40fd2838,
    name: "poll-winner-pollid"
  }, {
    path: "/poll/:pollid?",
    component: _9d5d54c4,
    name: "poll-pollid"
  }, {
    path: "/",
    component: _1d74cc96,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}

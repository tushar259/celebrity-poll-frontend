import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"C:\\xampp\\htdocs\\New folder\\new-nuxt-app\\node_modules\\vue-toastification\\dist\\index.css"});
  inject('toast', toast);
}
